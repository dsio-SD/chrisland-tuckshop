
import React from "react";

const TopUp = () => {
  return <div><h2>TopUp Page</h2></div>;
};

export default TopUp;
