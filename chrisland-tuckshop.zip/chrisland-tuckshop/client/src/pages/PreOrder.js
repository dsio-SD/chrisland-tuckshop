
import React from "react";

const PreOrder = () => {
  return <div><h2>PreOrder Page</h2></div>;
};

export default PreOrder;
