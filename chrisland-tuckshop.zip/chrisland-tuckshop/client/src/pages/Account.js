
import React from "react";

const Account = () => {
  return <div><h2>Account Page</h2></div>;
};

export default Account;
